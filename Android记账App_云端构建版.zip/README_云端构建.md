# Android 记账 App — 云端构建版

这个版本加入了 GitHub Actions，可以在云端自动编译 APK。

## 最简单的使用方法

1. 在 GitHub 新建一个空的 Repository。
2. 把这个项目里的全部文件上传到 Repository。
3. 打开仓库顶部的 **Actions**。
4. 选择 **Build Android APK**。
5. 点击 **Run workflow**（或者直接向 main 分支提交一次代码）。
6. 等待构建完成。
7. 打开完成的工作流，找到 **Artifacts**。
8. 下载 `AndroidBookkeeping-debug-apk`，里面就是 `app-debug.apk`。
9. 把 APK 传到 Android 手机并安装。

## 技术配置

- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.10
- JDK 17
- compileSdk 35
- minSdk 24
- 云端构建：GitHub Actions
- 输出：Debug APK

注意：这是测试/个人使用的 Debug APK。正式发布到应用商店时，还需要配置正式签名（keystore）。
