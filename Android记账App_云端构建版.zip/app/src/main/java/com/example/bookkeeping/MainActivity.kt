package com.example.bookkeeping

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Record(
    val id: Long,
    val type: String,
    val amount: Double,
    val category: String,
    val note: String,
    val date: String
)

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private val records = mutableListOf<Record>()
    private lateinit var list: LinearLayout
    private lateinit var incomeText: TextView
    private lateinit var expenseText: TextView
    private lateinit var balanceText: TextView
    private val green = Color.rgb(76,175,80)
    private val red = Color.rgb(230,75,75)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("bookkeeping", Context.MODE_PRIVATE)
        load()
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(248,249,250))
        }
        scroll.addView(root)

        val title = TextView(this).apply {
            text = "我的记账本"
            textSize = 28f
            setTextColor(Color.rgb(30,30,30))
            setPadding(0,0,0,18)
        }
        root.addView(title)

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(18,18,18,18)
            setBackgroundColor(Color.WHITE)
        }
        incomeText = stat("收入", green)
        expenseText = stat("支出", red)
        balanceText = stat("结余", Color.DKGRAY)
        stats.addView(incomeText, weightParams())
        stats.addView(expenseText, weightParams())
        stats.addView(balanceText, weightParams())
        root.addView(stats)

        val add = Button(this).apply {
            text = "＋ 添加一笔"
            textSize = 17f
            setOnClickListener { showAddDialog() }
        }
        root.addView(add, LinearLayout.LayoutParams(-1, -2).apply { topMargin=18; bottomMargin=18 })

        val heading = TextView(this).apply {
            text = "最近账单"
            textSize = 21f
            setTextColor(Color.DKGRAY)
            setPadding(0, 4, 0, 10)
        }
        root.addView(heading)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        setContentView(scroll)
        refresh()
    }

    private fun stat(name:String, color:Int): TextView = TextView(this).apply {
        text = "$name\n¥0.00"
        textSize = 15f
        setTextColor(color)
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, -2, 1f)

    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35,10,35,0)
        }
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("支出","收入"))
        val amount = EditText(this).apply { hint="金额，例如 25.50"; inputType=2 or 8192 }
        val category = EditText(this).apply { hint="分类，例如 餐饮 / 工资 / 购物" }
        val note = EditText(this).apply { hint="备注（可选）" }
        box.addView(type); box.addView(amount); box.addView(category); box.addView(note)

        AlertDialog.Builder(this)
            .setTitle("添加账单")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("保存") { _, _ ->
                val value = amount.text.toString().toDoubleOrNull()
                if (value == null || value <= 0) {
                    Toast.makeText(this, "请输入正确金额", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val c = category.text.toString().ifBlank { "其他" }
                val n = note.text.toString()
                val date = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                records.add(Record(System.currentTimeMillis(), type.selectedItem.toString(), value, c, n, date))
                save(); refresh()
            }.show()
    }

    private fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        var income=0.0; var expense=0.0
        records.forEach { if(it.type=="收入") income += it.amount else expense += it.amount }
        incomeText.text = "收入\n¥%.2f".format(income)
        expenseText.text = "支出\n¥%.2f".format(expense)
        balanceText.text = "结余\n¥%.2f".format(income-expense)

        records.sortedByDescending { it.id }.forEach { r ->
            val row = LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL
                setPadding(16,18,10,18)
                setBackgroundColor(Color.WHITE)
            }
            val info = TextView(this).apply {
                text = "${r.category}  ${if(r.note.isBlank()) "" else r.note}\n${r.date}"
                textSize=16f
                setTextColor(Color.DKGRAY)
            }
            val money = TextView(this).apply {
                text = "${if(r.type=="收入") "+" else "-"}¥%.2f".format(r.amount)
                textSize=17f
                setTextColor(if(r.type=="收入") green else red)
                gravity=Gravity.CENTER_VERTICAL
            }
            val del = Button(this).apply {
                text="删除"
                setOnClickListener {
                    records.removeAll { it.id==r.id }; save(); refresh()
                }
            }
            row.addView(info, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(money, LinearLayout.LayoutParams(100,-1))
            row.addView(del, LinearLayout.LayoutParams(80,-2))
            list.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=8 })
        }
        if(records.isEmpty()) {
            list.addView(TextView(this).apply {
                text="还没有账单\n点击上方“＋ 添加一笔”开始记账"
                textSize=17f; gravity=Gravity.CENTER; setPadding(0,50,0,50)
            })
        }
    }

    private fun save() {
        val a=JSONArray()
        records.forEach {
            a.put(JSONObject().apply {
                put("id",it.id); put("type",it.type); put("amount",it.amount)
                put("category",it.category); put("note",it.note); put("date",it.date)
            })
        }
        prefs.edit().putString("records",a.toString()).apply()
    }

    private fun load() {
        val s=prefs.getString("records","[]") ?: "[]"
        val a=JSONArray(s)
        for(i in 0 until a.length()) {
            val o=a.getJSONObject(i)
            records.add(Record(o.getLong("id"),o.getString("type"),o.getDouble("amount"),
                o.getString("category"),o.getString("note"),o.getString("date")))
        }
    }
}
