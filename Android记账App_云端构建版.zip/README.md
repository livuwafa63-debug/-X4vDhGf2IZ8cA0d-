# Android 记账 App

功能：
- 添加收入/支出
- 金额、分类、备注
- 本地保存
- 收入、支出、结余统计
- 最近账单列表
- 删除账单

打开方式：
1. 安装 Android Studio。
2. 解压项目。
3. Android Studio -> Open -> 选择项目目录。
4. 等待 Gradle 同步。
5. 连接 Android 手机并点击 Run。

最低 Android 版本：Android 7.0（API 24）。
